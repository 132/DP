public class FraserFir extends Tree
{
    public FraserFir()
    {
        description = "Fraser fir tree";
        cost = 12;
    }
}
