public abstract class Tree
{
    protected String description;
    protected int cost;

    public String getDescription()
    {
        return description;
    }

    public int getCost()
    {
        return cost;
    }
}
