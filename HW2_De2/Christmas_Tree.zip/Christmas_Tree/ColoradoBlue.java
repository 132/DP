public class ColoradoBlue extends Tree
{
    public ColoradoBlue()
    {
        description = "ColoradoBlue";
        cost = 20;
    }
}
