public class BallsRed extends Decoration
{
    public BallsRed(Tree t)
    {
        tree = t;
        cost = 1;
        description = ", blue balls";
    }
}
