public class BallsSilver extends Decoration
{
    public BallsSilver(Tree t)
    {
        tree = t;
        cost = 3;
        description = ", silver balls";
    }
}
