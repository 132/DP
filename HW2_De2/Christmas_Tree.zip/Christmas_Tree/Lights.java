public class Lights extends Decoration
{
    public Lights(Tree t)
    {
        tree = t;
        cost = 5;
        description = ", shining lights";
    }
}
